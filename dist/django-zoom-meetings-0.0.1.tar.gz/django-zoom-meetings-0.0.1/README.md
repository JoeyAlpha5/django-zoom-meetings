# Django Zoom Meetings

1.	 npm install
2.	npm start

